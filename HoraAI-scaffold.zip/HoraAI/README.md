# Hora AI — Personal Android Voice Assistant

A JARVIS-style voice assistant for Android. This is a **full project scaffold**:
architecture, DI, database, networking, and UI are wired end-to-end for the
core loop (wake word → listen → understand → act/respond → speak). Many of
the longer-tail features from the spec (custom commands UI, floating bubble,
widget, translate/currency/news, backup & restore) are stubbed with clear
`TODO`s and a defined place in the architecture to fill them in.

## What's implemented vs. stubbed

**Working end-to-end (once you add API keys):**
- Speech-to-text (Android SpeechRecognizer) — English/Hindi/Hinglish
- Text-to-speech (Android TTS, best-available-voice selection)
- AI chat via OpenAI Chat Completions, with in-session memory
- Local command routing: open apps, volume, flashlight, Wi-Fi/Bluetooth
  settings, battery/time/date/storage/RAM
- Room database (chat history, custom commands, preferences) — schema ready
- DataStore-backed settings (assistant name, wake word, language, theme,
  background listening)
- Premium dark blue-glow UI: animated AI orb, voice wave, mic button
- Runtime permission flow for core permissions

**Stubbed / needs finishing (structure is in place):**
- Wake word ("Hey Hora") — needs a trained Porcupine model, see below
- Floating bubble overlay (`FloatingBubbleService`)
- Home screen widget (`HoraWidgetProvider`)
- Quick Settings tile logic (`HoraTileService`)
- Custom commands ("Study Mode" macros) — DB schema exists, no UI yet
- Weather / news / search / translate / currency conversion
- Backup & Restore
- Call/SMS actions are wired but gated behind permissions you must request
  contextually in the UI

## Project structure

```
app/src/main/java/com/hora/ai/
  ui/           Compose screens, components (orb, mic, wave), theme, nav
  voice/        Speech-to-text, text-to-speech, wake word, command routing
  ai/           OpenAI Retrofit client + chat repository
  data/         (reserved for repositories mixing local+remote data)
  database/     Room entities, DAOs, AppDatabase
  settings/     DataStore-backed settings repository
  services/     Foreground service, app launcher, phone control, system info
  utils/        Constants, extensions
  permissions/  Permission checking
  di/           Hilt modules (network, database)
```

## Setup

1. **Open in Android Studio** (Koala/2024.1+ recommended). Let it sync and
   regenerate the Gradle wrapper (see `README_WRAPPER.txt`).

2. **Add your API keys.** Copy `local.properties.template` → `local.properties`
   and fill in:
   ```
   sdk.dir=/path/to/Android/sdk
   OPENAI_API_KEY=sk-...
   PORCUPINE_ACCESS_KEY=...
   ```
   `local.properties` is gitignored — never commit real keys.

3. **Wake word model.** Wake-word detection needs a trained model file:
   - Sign up free at https://console.picovoice.ai
   - Create a wake word for the phrase **"Hey Hora"**, platform **Android**
   - Download the `.ppn` file and place it at `app/src/main/assets/hey-hora_en_android.ppn`
   - Until this is done, `WakeWordDetector` will fail to start — the app
     still works fully via the tap-to-talk mic button.

4. **(Optional) Firebase.** If you want cloud sync/backup/analytics, create
   a Firebase project, download `google-services.json` into `app/`, and
   uncomment the Firebase plugin/dependencies in the Gradle files.

5. **Build & run** on your OPPO CPH2667 (or any Android 8.0+ device — the
   min SDK is set to 26 for broad compatibility, targeting 35).

## Notes on OEM (ColorOS) behavior

OPPO devices aggressively kill background services and restrict
auto-start. For reliable "Hey Hora" background listening you'll likely need
to guide users to:
- Settings → Battery → App Battery Management → Hora AI → "Allow background activity" / disable optimization
- Settings → App Management → Autostart → enable for Hora AI

Consider surfacing this as an in-app onboarding step.

## Known Android platform limitations

- There's no public API for a normal app to pull down the notification
  shade or trigger the system Recents screen — both require an
  AccessibilityService, which the spec marks optional. If you want these,
  I can add an AccessibilityService implementation next.
- Reading/replying to arbitrary notifications also requires a
  NotificationListenerService with explicit user approval — not yet wired.

## Building an APK

This scaffold can't be compiled into an APK outside Android Studio /
Gradle (this project was generated in an environment without the Android
SDK or network access). Once opened in Android Studio:

```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

or from the command line once the wrapper is generated:

```
./gradlew assembleDebug
```

The output APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
