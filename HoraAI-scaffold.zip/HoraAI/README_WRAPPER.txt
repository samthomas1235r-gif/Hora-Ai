The gradle-wrapper.jar binary itself isn't included (no network access when
this project was generated). To finish setup:

  1. Open this project folder in Android Studio (Giraffe/Koala or newer).
  2. Android Studio will offer to "Sync Now" / regenerate the Gradle wrapper
     automatically — accept it. That's usually all you need.

  OR, from a terminal with Gradle installed:
     gradle wrapper --gradle-version 8.7
