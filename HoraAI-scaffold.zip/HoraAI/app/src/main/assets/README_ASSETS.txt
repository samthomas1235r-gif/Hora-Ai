Place your trained Porcupine wake-word file here:
  hey-hora_en_android.ppn

Get it from https://console.picovoice.ai (free tier):
  1. Sign up / log in
  2. Porcupine -> Create Wake Word
  3. Enter phrase: "Hey Hora"
  4. Platform: Android
  5. Train and download the .ppn file
  6. Rename/place it here, matching the path used in
     voice/wakeword/WakeWordDetector.kt (setKeywordPath).

Also add your Access Key to local.properties:
  PORCUPINE_ACCESS_KEY=your_key_here
