package com.hora.ai.services

import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import com.hora.ai.utils.Constants
import com.hora.ai.utils.canResolveIntent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Handles "Open X" voice commands by launching the right app/intent. */
@Singleton
class AppLauncher @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun openApp(spokenName: String): Boolean {
        val key = spokenName.trim().lowercase()

        // Special cases that aren't a simple package launch
        val specialIntent: Intent? = when (key) {
            "camera" -> Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            "gallery" -> Intent(Intent.ACTION_VIEW).setType("image/*")
            "settings" -> Intent(Settings.ACTION_SETTINGS)
            "contacts" -> Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
            "phone", "dialer" -> Intent(Intent.ACTION_DIAL)
            "calculator" -> resolveCalculatorIntent()
            else -> null
        }
        if (specialIntent != null) {
            return launchIntent(specialIntent)
        }

        // Standard package-based apps
        val packageName = Constants.APP_PACKAGE_MAP[key]
        if (packageName != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            return if (launchIntent != null) launchIntent(launchIntent) else false
        }

        return false
    }

    /** Calculator package names vary a lot by OEM (ColorOS/OPPO included) — probe common ones. */
    private fun resolveCalculatorIntent(): Intent? {
        val candidates = listOf(
            "com.coloros.calculator",       // OPPO / ColorOS
            "com.oppo.calculator",
            "com.android.calculator2",
            "com.google.android.calculator",
            "com.miui.calculator"
        )
        for (pkg in candidates) {
            context.packageManager.getLaunchIntentForPackage(pkg)?.let { return it }
        }
        return null
    }

    private fun launchIntent(intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (context.canResolveIntent(intent)) {
            context.startActivity(intent)
            true
        } else {
            false
        }
    }
}
