package com.hora.ai.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import com.hora.ai.permissions.PermissionManager
import com.hora.ai.ui.navigation.HoraNavHost
import com.hora.ai.ui.theme.HoraAITheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var permissionManager: PermissionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            HoraAITheme {
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { /* results handled implicitly — screens re-check via PermissionManager */ }

                LaunchedEffect(Unit) {
                    val missing = permissionManager.missingCorePermissions()
                    if (missing.isNotEmpty()) {
                        launcher.launch(missing.toTypedArray())
                    }
                }

                HoraNavHost()
            }
        }

        // If launched by the wake-word service, EXTRA_TRIGGERED_BY_WAKE_WORD is true —
        // HomeViewModel/HomeScreen can read this from intent to auto-start listening.
        // (Left as a TODO hook: pass through a SavedStateHandle or Activity-scoped flow.)
    }
}
