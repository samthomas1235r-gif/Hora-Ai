package com.hora.ai.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.hora.ai.utils.Constants

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val assistantName by viewModel.repository.assistantName.collectAsState(initial = Constants.DEFAULT_ASSISTANT_NAME)
    val wakeWord by viewModel.repository.wakeWord.collectAsState(initial = Constants.DEFAULT_WAKE_WORD)
    val language by viewModel.repository.language.collectAsState(initial = "English")
    val darkMode by viewModel.repository.darkMode.collectAsState(initial = true)
    val backgroundListening by viewModel.repository.backgroundListeningEnabled.collectAsState(initial = false)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            item {
                ListItem(
                    headlineContent = { Text("Assistant name") },
                    supportingContent = { Text(assistantName) }
                    // TODO: tap to open a text-edit dialog -> viewModel.updateAssistantName(...)
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Wake word") },
                    supportingContent = { Text(wakeWord) }
                    // TODO: tap to open a text-edit dialog -> viewModel.updateWakeWord(...)
                    // Note: changing this requires retraining a new Porcupine .ppn model.
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Language") },
                    supportingContent = { Text(language) }
                    // TODO: tap to open selector among Constants.SUPPORTED_LANGUAGES
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Dark mode") },
                    trailingContent = {
                        Switch(checked = darkMode, onCheckedChange = { viewModel.updateDarkMode(it) })
                    }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Background listening (\"Hey Hora\")") },
                    supportingContent = { Text("Keeps Hora listening even when the app is closed") },
                    trailingContent = {
                        Switch(
                            checked = backgroundListening,
                            onCheckedChange = { viewModel.updateBackgroundListening(it) }
                        )
                    }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Voice selection") },
                    supportingContent = { Text("System TTS voice (upgrade to cloud TTS for a more natural voice)") }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Backup & Restore") },
                    supportingContent = { Text("Not yet implemented") }
                )
            }
            item {
                ListItem(
                    headlineContent = { Text("Privacy policy") }
                )
            }
        }
    }
}
