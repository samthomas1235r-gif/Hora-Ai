package com.hora.ai.voice.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

sealed class TtsEvent {
    data object Started : TtsEvent()
    data object Finished : TtsEvent()
    data class Error(val utteranceId: String) : TtsEvent()
}

/**
 * Wraps Android TextToSpeech. Voice selection ("natural human-like voice")
 * is limited to whatever voices the device/OEM (or an installed engine like
 * Google's) exposes — see selectMostNaturalVoice(). For a materially better
 * voice than the system TTS, swap this implementation for a cloud TTS API
 * (e.g. ElevenLabs, Google Cloud TTS, OpenAI TTS) behind the same interface.
 */
@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var tts: TextToSpeech? = null
    private var isReady = false

    fun initialize(onReady: (Boolean) -> Unit) {
        tts = TextToSpeech(context) { status ->
            isReady = status == TextToSpeech.SUCCESS
            if (isReady) {
                tts?.language = Locale.forLanguageTag("en-IN")
                selectMostNaturalVoice()
            }
            onReady(isReady)
        }
    }

    private fun selectMostNaturalVoice() {
        val voices: Set<Voice> = tts?.voices ?: return
        // Prefer a network/"enhanced" quality voice over the compact offline one, if available.
        val best = voices
            .filter { it.locale.language == "en" }
            .maxByOrNull { it.quality }
        best?.let { tts?.voice = it }
    }

    fun setLanguage(localeTag: String) {
        tts?.language = Locale.forLanguageTag(localeTag)
    }

    fun setPitchAndRate(pitch: Float = 1.0f, rate: Float = 1.0f) {
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
    }

    /** Speaks text and emits lifecycle events as a Flow (useful for driving the voice-wave UI). */
    fun speak(text: String): Flow<TtsEvent> = callbackFlow {
        val utteranceId = UUID.randomUUID().toString()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {
                trySend(TtsEvent.Started)
            }
            override fun onDone(id: String?) {
                trySend(TtsEvent.Finished)
                close()
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                trySend(TtsEvent.Error(id.orEmpty()))
                close()
            }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)

        awaitClose { /* no-op: don't stop() here, allow queued speech to finish */ }
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
