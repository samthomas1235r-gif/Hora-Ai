package com.hora.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.hora.ai.ui.theme.HoraBlueBright
import com.hora.ai.ui.theme.HoraCyanAccent

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * The circular "AI orb" — the visual centerpiece of the home screen.
 * Pulses gently when idle, glows brighter and faster while listening/speaking.
 */
@Composable
fun AiOrb(
    state: OrbState,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "orb")

    val pulseDurationMs = when (state) {
        OrbState.IDLE -> 2600
        OrbState.LISTENING -> 900
        OrbState.THINKING -> 650
        OrbState.SPEAKING -> 500
    }

    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val glowAlpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = if (state == OrbState.IDLE) 0.6f else 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Canvas(modifier = modifier.size(220.dp)) {
        val radius = size.minDimension / 2.4f * pulse
        val center = Offset(size.width / 2, size.height / 2)

        // Outer soft glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(HoraBlueBright.copy(alpha = glowAlpha), Color.Transparent),
                center = center,
                radius = radius * 1.8f
            ),
            radius = radius * 1.8f,
            center = center
        )

        // Core orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(HoraCyanAccent, HoraBlueBright),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )
    }
}
