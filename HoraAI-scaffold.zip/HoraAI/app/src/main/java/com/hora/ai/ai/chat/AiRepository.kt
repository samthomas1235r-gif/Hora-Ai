package com.hora.ai.ai.chat

import com.hora.ai.ai.openai.ChatCompletionRequest
import com.hora.ai.ai.openai.ChatMessageDto
import com.hora.ai.ai.openai.OpenAiApiService
import com.hora.ai.utils.Constants
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Owns the in-session conversation history and talks to the LLM.
 * History is kept in memory only (per your "remember conversation during
 * the session" requirement) — wire this to Room if you want persistence
 * across app restarts (see database/entities for a ready-made ChatMessageEntity).
 */
@Singleton
class AiRepository @Inject constructor(
    private val api: OpenAiApiService
) {
    private val sessionHistory = mutableListOf<ChatMessage>()

    private val systemPrompt = ChatMessageDto(
        role = "system",
        content = "You are Hora, a helpful, warm, JARVIS-style personal voice assistant. " +
            "Keep spoken replies concise (1-3 sentences) unless asked for detail. " +
            "You can respond in English, Hindi, or Hinglish depending on how the user speaks to you."
    )

    suspend fun sendMessage(userText: String): Result<String> {
        sessionHistory.add(ChatMessage(ChatMessage.Role.USER, userText))
        return try {
            val messages = listOf(systemPrompt) + sessionHistory.map {
                ChatMessageDto(
                    role = if (it.role == ChatMessage.Role.USER) "user" else "assistant",
                    content = it.content
                )
            }
            val response = api.createChatCompletion(
                ChatCompletionRequest(model = Constants.OPENAI_CHAT_MODEL, messages = messages)
            )
            val reply = response.choices.firstOrNull()?.message?.content.orEmpty()
            sessionHistory.add(ChatMessage(ChatMessage.Role.ASSISTANT, reply))
            Result.success(reply)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearSession() {
        sessionHistory.clear()
    }

    fun history(): List<ChatMessage> = sessionHistory.toList()
}
