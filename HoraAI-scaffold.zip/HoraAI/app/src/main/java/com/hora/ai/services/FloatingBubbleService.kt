package com.hora.ai.services

import android.app.Service
import android.content.Intent
import dagger.hilt.android.AndroidEntryPoint

/**
 * STUB: Floating assistant bubble (draggable overlay icon, tap to talk).
 * Requires SYSTEM_ALERT_WINDOW permission (granted via Settings, not a
 * standard runtime prompt) and a WindowManager-attached ComposeView.
 *
 * TODO:
 *  - Request "Draw over other apps" permission from Settings.ACTION_MANAGE_OVERLAY_PERMISSION
 *  - Inflate a ComposeView with the AiOrb component into a WindowManager overlay
 *  - Add drag-to-move + tap-to-activate-mic gesture handling
 */
@AndroidEntryPoint
class FloatingBubbleService : Service() {
    override fun onBind(intent: Intent?) = null
}
