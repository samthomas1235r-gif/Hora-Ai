package com.hora.ai.di

import android.content.Context
import androidx.room.Room
import com.hora.ai.database.AppDatabase
import com.hora.ai.database.dao.ChatMessageDao
import com.hora.ai.database.dao.CustomCommandDao
import com.hora.ai.database.dao.UserPreferenceDao
import com.hora.ai.utils.Constants
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, Constants.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideChatMessageDao(db: AppDatabase): ChatMessageDao = db.chatMessageDao()

    @Provides
    fun provideCustomCommandDao(db: AppDatabase): CustomCommandDao = db.customCommandDao()

    @Provides
    fun provideUserPreferenceDao(db: AppDatabase): UserPreferenceDao = db.userPreferenceDao()
}
