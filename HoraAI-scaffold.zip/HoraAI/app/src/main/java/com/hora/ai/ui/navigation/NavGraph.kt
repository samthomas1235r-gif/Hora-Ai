package com.hora.ai.ui.navigation

sealed class HoraDestination(val route: String) {
    data object Home : HoraDestination("home")
    data object Settings : HoraDestination("settings")
    data object CustomCommands : HoraDestination("custom_commands")
}
