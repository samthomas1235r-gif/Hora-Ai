package com.hora.ai.ai.chat

/** In-memory / persisted representation of a single turn in the conversation. */
data class ChatMessage(
    val role: Role,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Role { USER, ASSISTANT, SYSTEM }
}
