package com.hora.ai.voice.wakeword

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.content.Context
import com.hora.ai.BuildConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Always-on "Hey Hora" wake word detection using Picovoice Porcupine.
 *
 * SETUP REQUIRED (not something that can be done from code alone):
 *  1. Create a free account at https://console.picovoice.ai
 *  2. Train a custom wake-word model for the phrase "Hey Hora" (Porcupine
 *     Console -> Create Wake Word -> Android platform).
 *  3. Download the resulting `hey-hora_en_android.ppn` file and place it in
 *     app/src/main/assets/
 *  4. Put your Picovoice AccessKey in local.properties as PORCUPINE_ACCESS_KEY.
 *
 * Until that's done, this class will fail to initialize — callers should
 * catch that and fall back to a manual "tap to talk" flow (see MicButton).
 */
@Singleton
class WakeWordDetector @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var porcupineManager: PorcupineManager? = null

    fun start(onWakeWordDetected: () -> Unit, onError: (Throwable) -> Unit) {
        try {
            val callback = PorcupineManagerCallback { onWakeWordDetected() }
            porcupineManager = PorcupineManager.Builder()
                .setAccessKey(BuildConfig.PORCUPINE_ACCESS_KEY)
                .setKeywordPath("hey-hora_en_android.ppn") // asset-relative path
                .setSensitivity(0.6f)
                .build(context, callback)
            porcupineManager?.start()
        } catch (t: Throwable) {
            onError(t)
        }
    }

    fun stop() {
        try {
            porcupineManager?.stop()
            porcupineManager?.delete()
        } catch (_: Throwable) {
            // no-op — best-effort cleanup
        } finally {
            porcupineManager = null
        }
    }

    fun isRunning(): Boolean = porcupineManager != null
}
