package com.hora.ai.services

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.hora.ai.HoraApplication
import com.hora.ai.R
import com.hora.ai.ui.MainActivity
import com.hora.ai.voice.wakeword.WakeWordDetector
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Foreground service that keeps the Porcupine wake-word engine running so
 * "Hey Hora" works even when the app isn't in the foreground. Started from
 * MainActivity once the user enables Voice Mode / background listening.
 */
@AndroidEntryPoint
class AssistantForegroundService : Service() {

    @Inject lateinit var wakeWordDetector: WakeWordDetector

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        startWakeWordListening()
    }

    private fun startWakeWordListening() {
        wakeWordDetector.start(
            onWakeWordDetected = {
                // Launch (or bring to front) the assistant UI in active-listening mode.
                val intent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    putExtra(com.hora.ai.utils.Constants.EXTRA_TRIGGERED_BY_WAKE_WORD, true)
                }
                startActivity(intent)
            },
            onError = { /* Wake word engine not configured yet — see WakeWordDetector docs */ }
        )
    }

    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, HoraApplication.CHANNEL_ASSISTANT_SERVICE)
            .setContentTitle("Hora is listening")
            .setContentText("Say \"Hey Hora\" to activate")
            .setSmallIcon(R.drawable.ic_hora_notification)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        wakeWordDetector.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}
