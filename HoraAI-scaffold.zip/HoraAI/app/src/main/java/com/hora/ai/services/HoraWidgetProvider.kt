package com.hora.ai.services

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

/**
 * STUB: Home-screen widget with a big mic button that launches MainActivity
 * directly into listening mode. TODO: build RemoteViews layout in
 * res/layout/widget_hora.xml and wire a PendingIntent to MainActivity with
 * EXTRA_TRIGGERED_BY_WAKE_WORD-style "start listening immediately" extra.
 */
class HoraWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)
        // TODO: implement RemoteViews binding per widget id
    }
}
