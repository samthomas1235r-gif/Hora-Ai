package com.hora.ai.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.hora.ai.database.dao.ChatMessageDao
import com.hora.ai.database.dao.CustomCommandDao
import com.hora.ai.database.dao.UserPreferenceDao
import com.hora.ai.database.entity.ChatMessageEntity
import com.hora.ai.database.entity.CustomCommandEntity
import com.hora.ai.database.entity.UserPreferenceEntity

@Database(
    entities = [ChatMessageEntity::class, CustomCommandEntity::class, UserPreferenceEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun customCommandDao(): CustomCommandDao
    abstract fun userPreferenceDao(): UserPreferenceDao
}
