package com.hora.ai.utils

/** Simple sealed representation of a runtime permission request outcome. */
sealed class PermissionResult {
    data object Granted : PermissionResult()
    data object Denied : PermissionResult()
    data object PermanentlyDenied : PermissionResult()
}
