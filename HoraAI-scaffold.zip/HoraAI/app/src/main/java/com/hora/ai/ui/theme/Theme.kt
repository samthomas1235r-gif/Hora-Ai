package com.hora.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = HoraBlueGlow,
    secondary = HoraCyanAccent,
    background = HoraBackground,
    surface = HoraSurface,
    surfaceVariant = HoraSurfaceElevated,
    onBackground = HoraTextPrimary,
    onSurface = HoraTextPrimary,
    error = HoraError
)

private val LightColors = lightColorScheme(
    primary = HoraBlueGlow,
    secondary = HoraCyanAccent,
    background = HoraLightBackground,
    surface = HoraLightSurface,
    error = HoraError
)

@Composable
fun HoraAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = HoraTypography,
        content = content
    )
}
