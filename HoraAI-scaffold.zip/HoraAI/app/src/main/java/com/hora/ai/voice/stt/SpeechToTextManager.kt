package com.hora.ai.voice.stt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

sealed class SttResult {
    data class PartialResult(val text: String) : SttResult()
    data class FinalResult(val text: String) : SttResult()
    data class Error(val message: String) : SttResult()
    data object ListeningStarted : SttResult()
    data object ListeningEnded : SttResult()
}

/**
 * Wraps Android's on-device SpeechRecognizer for one-shot and streaming
 * recognition. Supports English / Hindi / Hinglish by switching the
 * recognizer locale (Hinglish uses en-IN with mixed-language grammar,
 * which the on-device recognizer generally handles reasonably well).
 */
@Singleton
class SpeechToTextManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var recognizer: SpeechRecognizer? = null

    fun isRecognitionAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * Starts listening and emits partial + final transcripts as a Flow.
     * Collect this from a coroutine scope tied to the mic-button/voice-mode lifecycle.
     */
    fun listen(languageTag: String = "en-IN"): Flow<SttResult> = callbackFlow {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    trySend(SttResult.ListeningStarted)
                }

                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    trySend(SttResult.FinalResult(text))
                    trySend(SttResult.ListeningEnded)
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val text = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) trySend(SttResult.PartialResult(text))
                }

                override fun onError(error: Int) {
                    trySend(SttResult.Error("Speech recognition error code: $error"))
                    trySend(SttResult.ListeningEnded)
                }

                override fun onEndOfSpeech() {
                    trySend(SttResult.ListeningEnded)
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(intent)
        }

        awaitClose {
            recognizer?.stopListening()
            recognizer?.destroy()
            recognizer = null
        }
    }

    fun stop() {
        recognizer?.stopListening()
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
    }
}
