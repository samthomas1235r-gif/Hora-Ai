package com.hora.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.hora.ai.ui.components.AiOrb
import com.hora.ai.ui.components.MicButton
import com.hora.ai.ui.components.VoiceWaveAnimation
import com.hora.ai.ui.components.OrbState

@Composable
fun HomeScreen(
    onNavigateToSettings: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                IconButton(onClick = onNavigateToSettings, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AiOrb(state = uiState.orbState)

            Spacer(modifier = Modifier.height(24.dp))

            VoiceWaveAnimation(isActive = uiState.orbState != OrbState.IDLE)

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = uiState.transcript.ifBlank { "Say \u201cHey Hora\u201d or tap the mic" },
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )

            if (uiState.assistantReply.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = uiState.assistantReply,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            MicButton(
                isListening = uiState.isListening,
                onClick = { viewModel.startListening() }
            )
        }
    }
}
