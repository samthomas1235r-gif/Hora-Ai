package com.hora.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.hora.ai.ui.theme.HoraBlueBright
import kotlin.math.sin

/**
 * Animated equalizer-style bars shown while listening/speaking.
 * `amplitude` (0f–1f) can be driven by STT RMS changes or TTS playback for
 * a more reactive effect; defaults to a smooth idle animation otherwise.
 */
@Composable
fun VoiceWaveAnimation(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 5
) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (isActive) 2f * Math.PI.toFloat() else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(
        modifier = modifier
            .width((barCount * 14).dp)
            .height(40.dp)
    ) {
        val barWidth = size.width / (barCount * 2f)
        for (i in 0 until barCount) {
            val heightFraction = if (isActive) {
                (0.3f + 0.7f * kotlin.math.abs(sin(phase + i * 0.6f)))
            } else 0.15f
            val barHeight = size.height * heightFraction
            val x = barWidth * (i * 2 + 1)
            drawLine(
                color = HoraBlueBright,
                start = androidx.compose.ui.geometry.Offset(x, size.height / 2 - barHeight / 2),
                end = androidx.compose.ui.geometry.Offset(x, size.height / 2 + barHeight / 2),
                strokeWidth = barWidth,
                cap = StrokeCap.Round
            )
        }
    }
}
