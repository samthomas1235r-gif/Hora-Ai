package com.hora.ai.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Key-value store for learned user preferences ("remember user preferences"). */
@Entity(tableName = "user_preferences")
data class UserPreferenceEntity(
    @PrimaryKey val key: String,
    val value: String
)
