package com.hora.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. Hilt's dependency graph is rooted here.
 */
@HiltAndroidApp
class HoraApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val assistantChannel = NotificationChannel(
                CHANNEL_ASSISTANT_SERVICE,
                "Hora Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Hora listening for \"Hey Hora\" in the background"
            }

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "Hora Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Reminders and important assistant notifications"
            }

            manager.createNotificationChannel(assistantChannel)
            manager.createNotificationChannel(alertsChannel)
        }
    }

    companion object {
        const val CHANNEL_ASSISTANT_SERVICE = "hora_assistant_service"
        const val CHANNEL_ALERTS = "hora_alerts"
    }
}
