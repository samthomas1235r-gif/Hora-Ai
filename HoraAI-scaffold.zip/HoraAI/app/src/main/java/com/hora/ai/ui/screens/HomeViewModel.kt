package com.hora.ai.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hora.ai.ai.chat.AiRepository
import com.hora.ai.ui.components.OrbState
import com.hora.ai.voice.CommandOutcome
import com.hora.ai.voice.VoiceCommandProcessor
import com.hora.ai.voice.stt.SpeechToTextManager
import com.hora.ai.voice.stt.SttResult
import com.hora.ai.voice.tts.TextToSpeechManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val orbState: OrbState = OrbState.IDLE,
    val isListening: Boolean = false,
    val transcript: String = "",
    val assistantReply: String = "",
    val voiceModeEnabled: Boolean = true
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val sttManager: SpeechToTextManager,
    private val ttsManager: TextToSpeechManager,
    private val commandProcessor: VoiceCommandProcessor,
    private val aiRepository: AiRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        ttsManager.initialize(onReady = { /* ready for speak() calls */ })
    }

    fun toggleVoiceMode() {
        _uiState.value = _uiState.value.copy(voiceModeEnabled = !_uiState.value.voiceModeEnabled)
    }

    /** Called when the user taps the mic button (or the wake word fires). */
    fun startListening() {
        if (!sttManager.isRecognitionAvailable()) return

        _uiState.value = _uiState.value.copy(isListening = true, orbState = OrbState.LISTENING)

        viewModelScope.launch {
            sttManager.listen().collect { result ->
                when (result) {
                    is SttResult.PartialResult -> {
                        _uiState.value = _uiState.value.copy(transcript = result.text)
                    }
                    is SttResult.FinalResult -> {
                        _uiState.value = _uiState.value.copy(transcript = result.text)
                        handleFinalTranscript(result.text)
                    }
                    is SttResult.Error -> {
                        _uiState.value = _uiState.value.copy(isListening = false, orbState = OrbState.IDLE)
                    }
                    SttResult.ListeningStarted -> Unit
                    SttResult.ListeningEnded -> {
                        _uiState.value = _uiState.value.copy(isListening = false)
                    }
                }
            }
        }
    }

    private fun handleFinalTranscript(text: String) {
        if (text.isBlank()) {
            _uiState.value = _uiState.value.copy(orbState = OrbState.IDLE)
            return
        }

        _uiState.value = _uiState.value.copy(orbState = OrbState.THINKING)

        when (val outcome = commandProcessor.process(text)) {
            is CommandOutcome.Handled -> speak(outcome.spokenReply)
            is CommandOutcome.NotRecognized -> askAi(outcome.rawText)
        }
    }

    private fun askAi(text: String) {
        viewModelScope.launch {
            val result = aiRepository.sendMessage(text)
            result.onSuccess { reply -> speak(reply) }
                .onFailure { speak("Sorry, I couldn't reach the AI service right now.") }
        }
    }

    private fun speak(text: String) {
        _uiState.value = _uiState.value.copy(assistantReply = text, orbState = OrbState.SPEAKING)
        viewModelScope.launch {
            ttsManager.speak(text).collect { /* drives orb/wave animation via orbState above */ }
            _uiState.value = _uiState.value.copy(orbState = OrbState.IDLE)
        }
    }

    override fun onCleared() {
        sttManager.destroy()
        ttsManager.shutdown()
        super.onCleared()
    }
}
