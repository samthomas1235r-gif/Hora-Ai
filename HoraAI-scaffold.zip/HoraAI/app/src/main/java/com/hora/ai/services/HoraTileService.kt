package com.hora.ai.services

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * STUB: Quick Settings tile toggling Hora's background listening on/off.
 * TODO: read/write listening state via SettingsRepository (DataStore) and
 * start/stop AssistantForegroundService accordingly.
 */
class HoraTileService : TileService() {

    override fun onClick() {
        super.onClick()
        val tile = qsTile ?: return
        tile.state = if (tile.state == Tile.STATE_ACTIVE) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        tile.updateTile()
    }

    override fun onStartListening() {
        super.onStartListening()
        // TODO: sync tile.state with actual service running-state
    }
}
