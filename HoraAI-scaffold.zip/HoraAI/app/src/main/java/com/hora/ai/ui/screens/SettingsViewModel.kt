package com.hora.ai.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hora.ai.settings.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val repository: SettingsRepository
) : ViewModel() {

    fun updateAssistantName(name: String) = viewModelScope.launch {
        repository.setAssistantName(name)
    }

    fun updateWakeWord(phrase: String) = viewModelScope.launch {
        repository.setWakeWord(phrase)
    }

    fun updateLanguage(language: String) = viewModelScope.launch {
        repository.setLanguage(language)
    }

    fun updateDarkMode(enabled: Boolean) = viewModelScope.launch {
        repository.setDarkMode(enabled)
    }

    fun updateBackgroundListening(enabled: Boolean) = viewModelScope.launch {
        repository.setBackgroundListeningEnabled(enabled)
    }
}
