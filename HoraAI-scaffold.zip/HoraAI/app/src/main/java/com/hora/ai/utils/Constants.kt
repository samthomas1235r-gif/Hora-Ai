package com.hora.ai.utils

/**
 * App-wide constants. Keep magic strings/numbers out of business logic.
 */
object Constants {
    const val DEFAULT_ASSISTANT_NAME = "Hora"
    const val DEFAULT_WAKE_WORD = "Hey Hora"

    const val OPENAI_BASE_URL = "https://api.openai.com/"
    const val OPENAI_CHAT_MODEL = "gpt-4o-mini"

    const val DATASTORE_NAME = "hora_settings"
    const val DATABASE_NAME = "hora_database"

    // Intent extras
    const val EXTRA_VOICE_COMMAND = "extra_voice_command"
    const val EXTRA_TRIGGERED_BY_WAKE_WORD = "extra_triggered_by_wake_word"

    // Supported languages (extend as needed)
    val SUPPORTED_LANGUAGES = listOf("English", "Hindi", "Hinglish")

    // Package names for app control ("Open YouTube" etc.)
    val APP_PACKAGE_MAP = mapOf(
        "youtube" to "com.google.android.youtube",
        "telegram" to "org.telegram.messenger",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "camera" to null, // resolved via MediaStore/Camera intent instead of package
        "gallery" to null, // resolved via ACTION_VIEW image intent
        "settings" to null, // resolved via Settings.ACTION_SETTINGS
        "calculator" to null, // device-specific package, resolved via PackageManager query
        "contacts" to null, // resolved via ContactsContract intent
        "phone" to null, // resolved via ACTION_DIAL
        "gmail" to "com.google.android.gm"
    )
}
