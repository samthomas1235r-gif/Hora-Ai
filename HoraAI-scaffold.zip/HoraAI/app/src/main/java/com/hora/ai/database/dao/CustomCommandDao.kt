package com.hora.ai.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.hora.ai.database.entity.CustomCommandEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomCommandDao {
    @Insert
    suspend fun insert(command: CustomCommandEntity)

    @Delete
    suspend fun delete(command: CustomCommandEntity)

    @Query("SELECT * FROM custom_commands ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CustomCommandEntity>>

    @Query("SELECT * FROM custom_commands WHERE triggerPhrase = :phrase LIMIT 1")
    suspend fun findByTrigger(phrase: String): CustomCommandEntity?
}
