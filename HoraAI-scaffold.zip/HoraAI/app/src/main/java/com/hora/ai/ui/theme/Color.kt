package com.hora.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Premium dark theme — blue glowing AI aesthetic
val HoraBackground = Color(0xFF07090F)
val HoraSurface = Color(0xFF10141F)
val HoraSurfaceElevated = Color(0xFF171D2C)

val HoraBlueGlow = Color(0xFF3B82F6)      // primary glow accent
val HoraBlueBright = Color(0xFF60A5FA)
val HoraCyanAccent = Color(0xFF22D3EE)

val HoraTextPrimary = Color(0xFFE8EDF7)
val HoraTextSecondary = Color(0xFF8A93A6)

val HoraError = Color(0xFFEF4444)
val HoraSuccess = Color(0xFF22C55E)

// Light theme fallback (Settings -> Light mode)
val HoraLightBackground = Color(0xFFF5F7FB)
val HoraLightSurface = Color(0xFFFFFFFF)
