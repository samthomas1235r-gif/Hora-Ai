package com.hora.ai.database.dao

import androidx.room.Dao
import androidx.room.OnConflictStrategy
import androidx.room.Insert
import androidx.room.Query
import com.hora.ai.database.entity.UserPreferenceEntity

@Dao
interface UserPreferenceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(preference: UserPreferenceEntity)

    @Query("SELECT * FROM user_preferences WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): UserPreferenceEntity?
}
