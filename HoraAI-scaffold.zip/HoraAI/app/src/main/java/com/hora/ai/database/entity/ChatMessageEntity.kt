package com.hora.ai.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Optional persisted chat history (session memory is in-memory by default — see AiRepository). */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val timestamp: Long
)
