package com.hora.ai.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A user-defined voice macro, e.g. trigger phrase "study mode" ->
 * actions ["open youtube", "open notes", "open calculator"].
 * `actionsJson` stores a JSON-encoded List<String> of sub-commands that get
 * replayed through VoiceCommandProcessor in order.
 */
@Entity(tableName = "custom_commands")
data class CustomCommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val triggerPhrase: String,
    val actionsJson: String,
    val createdAt: Long = System.currentTimeMillis()
)
