package com.hora.ai.voice

import com.hora.ai.services.AppLauncher
import com.hora.ai.services.PhoneController
import com.hora.ai.services.SystemInfoProvider
import com.hora.ai.utils.normalizeCommand
import javax.inject.Inject
import javax.inject.Singleton

/** Outcome of processing a spoken command — tells the UI/TTS layer what happened. */
sealed class CommandOutcome {
    data class Handled(val spokenReply: String) : CommandOutcome()
    data class NotRecognized(val rawText: String) : CommandOutcome()
}

/**
 * Routes a normalized transcript to the right local handler (app control,
 * phone control, system info) via simple keyword matching first — falling
 * back to the AI chat layer (see ai/) when nothing local matches.
 *
 * This keyword-first approach keeps common commands fast + working fully
 * offline, and only spends an API call on genuinely conversational input.
 */
@Singleton
class VoiceCommandProcessor @Inject constructor(
    private val appLauncher: AppLauncher,
    private val phoneController: PhoneController,
    private val systemInfoProvider: SystemInfoProvider
) {

    fun process(rawText: String): CommandOutcome {
        val text = rawText.normalizeCommand()

        openAppCommand(text)?.let { return it }
        phoneControlCommand(text)?.let { return it }
        systemInfoCommand(text)?.let { return it }

        return CommandOutcome.NotRecognized(rawText)
    }

    private fun openAppCommand(text: String): CommandOutcome? {
        if (!text.startsWith("open ")) return null
        val target = text.removePrefix("open ").trim()
        val opened = appLauncher.openApp(target)
        return if (opened) {
            CommandOutcome.Handled("Opening $target")
        } else {
            CommandOutcome.Handled("I couldn't find $target on this device")
        }
    }

    private fun phoneControlCommand(text: String): CommandOutcome? = when {
        text.contains("increase volume") || text.contains("volume up") -> {
            phoneController.adjustVolume(raise = true)
            CommandOutcome.Handled("Volume up")
        }
        text.contains("decrease volume") || text.contains("volume down") -> {
            phoneController.adjustVolume(raise = false)
            CommandOutcome.Handled("Volume down")
        }
        text.contains("flashlight on") || text.contains("torch on") -> {
            phoneController.setFlashlight(true)
            CommandOutcome.Handled("Flashlight on")
        }
        text.contains("flashlight off") || text.contains("torch off") -> {
            phoneController.setFlashlight(false)
            CommandOutcome.Handled("Flashlight off")
        }
        text.contains("wifi") && text.contains("setting") -> {
            phoneController.openWifiSettings()
            CommandOutcome.Handled("Opening Wi-Fi settings")
        }
        text.contains("bluetooth") && text.contains("setting") -> {
            phoneController.openBluetoothSettings()
            CommandOutcome.Handled("Opening Bluetooth settings")
        }
        else -> null
    }

    private fun systemInfoCommand(text: String): CommandOutcome? = when {
        text.contains("battery") -> {
            val (pct, charging) = systemInfoProvider.batteryStatus()
            val chargingText = if (charging) "and charging" else "and not charging"
            CommandOutcome.Handled("Battery is at $pct percent $chargingText")
        }
        text.contains("what time") || text == "time" -> {
            CommandOutcome.Handled("It's ${systemInfoProvider.currentTime()}")
        }
        text.contains("what date") || text.contains("today's date") -> {
            CommandOutcome.Handled("Today is ${systemInfoProvider.currentDate()}")
        }
        text.contains("storage") -> {
            CommandOutcome.Handled(systemInfoProvider.storageInfo())
        }
        text.contains("ram") || text.contains("memory") -> {
            CommandOutcome.Handled(systemInfoProvider.ramInfo())
        }
        else -> null
    }
}
