package com.hora.ai.utils

import android.content.Context
import android.content.Intent
import android.widget.Toast

fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun Context.canResolveIntent(intent: Intent): Boolean =
    intent.resolveActivity(packageManager) != null

/** Normalizes recognized speech for command matching: lowercase, trimmed, punctuation stripped. */
fun String.normalizeCommand(): String =
    trim().lowercase().replace(Regex("[.,!?]"), "")
