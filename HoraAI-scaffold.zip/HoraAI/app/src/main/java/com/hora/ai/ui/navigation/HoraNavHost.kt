package com.hora.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.hora.ai.ui.screens.HomeScreen
import com.hora.ai.ui.screens.SettingsScreen

@Composable
fun HoraNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = HoraDestination.Home.route) {
        composable(HoraDestination.Home.route) {
            HomeScreen(onNavigateToSettings = { navController.navigate(HoraDestination.Settings.route) })
        }
        composable(HoraDestination.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        // TODO: composable(HoraDestination.CustomCommands.route) { CustomCommandsScreen(...) }
    }
}
