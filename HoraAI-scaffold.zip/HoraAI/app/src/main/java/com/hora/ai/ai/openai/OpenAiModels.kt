package com.hora.ai.ai.openai

import com.google.gson.annotations.SerializedName

data class ChatCompletionRequest(
    val model: String,
    val messages: List<ChatMessageDto>,
    val temperature: Double = 0.7
)

data class ChatMessageDto(
    val role: String, // "system" | "user" | "assistant"
    val content: String
)

data class ChatCompletionResponse(
    val choices: List<Choice>,
    @SerializedName("usage") val usage: Usage?
)

data class Choice(
    val index: Int,
    val message: ChatMessageDto,
    @SerializedName("finish_reason") val finishReason: String?
)

data class Usage(
    @SerializedName("prompt_tokens") val promptTokens: Int,
    @SerializedName("completion_tokens") val completionTokens: Int,
    @SerializedName("total_tokens") val totalTokens: Int
)
