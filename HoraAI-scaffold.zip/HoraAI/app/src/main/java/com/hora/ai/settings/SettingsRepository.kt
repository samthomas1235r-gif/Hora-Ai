package com.hora.ai.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.hora.ai.utils.Constants
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = Constants.DATASTORE_NAME)

/** Persists user-configurable settings: assistant name, wake word, voice, language, theme. */
@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
        val WAKE_WORD = stringPreferencesKey("wake_word")
        val LANGUAGE = stringPreferencesKey("language")
        val VOICE_ID = stringPreferencesKey("voice_id")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val VOICE_MODE_ENABLED = booleanPreferencesKey("voice_mode_enabled")
        val BACKGROUND_LISTENING = booleanPreferencesKey("background_listening")
    }

    val assistantName: Flow<String> = context.dataStore.data.map {
        it[Keys.ASSISTANT_NAME] ?: Constants.DEFAULT_ASSISTANT_NAME
    }

    val wakeWord: Flow<String> = context.dataStore.data.map {
        it[Keys.WAKE_WORD] ?: Constants.DEFAULT_WAKE_WORD
    }

    val language: Flow<String> = context.dataStore.data.map {
        it[Keys.LANGUAGE] ?: "English"
    }

    val darkMode: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.DARK_MODE] ?: true // premium dark theme by default
    }

    val voiceModeEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.VOICE_MODE_ENABLED] ?: true
    }

    val backgroundListeningEnabled: Flow<Boolean> = context.dataStore.data.map {
        it[Keys.BACKGROUND_LISTENING] ?: false
    }

    suspend fun setAssistantName(name: String) {
        context.dataStore.edit { it[Keys.ASSISTANT_NAME] = name }
    }

    suspend fun setWakeWord(phrase: String) {
        context.dataStore.edit { it[Keys.WAKE_WORD] = phrase }
    }

    suspend fun setLanguage(language: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_MODE] = enabled }
    }

    suspend fun setVoiceModeEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOICE_MODE_ENABLED] = enabled }
    }

    suspend fun setBackgroundListeningEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BACKGROUND_LISTENING] = enabled }
    }
}
