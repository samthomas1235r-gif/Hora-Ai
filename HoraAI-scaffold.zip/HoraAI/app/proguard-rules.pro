# Keep Retrofit/Gson model classes (reflection-based serialization)
-keep class com.hora.ai.ai.openai.** { *; }
-keep class com.hora.ai.database.entity.** { *; }

# Retrofit
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn retrofit2.**

# Hilt / Dagger
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager

# Porcupine (JNI bindings)
-keep class ai.picovoice.porcupine.** { *; }
